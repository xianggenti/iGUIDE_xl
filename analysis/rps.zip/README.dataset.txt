# Rock Paper Scissors (Small) > 300x300-raw
https://public.roboflow.ai/classification/rock-paper-scissors-(small)

Provided by [Laurence Maroney ](https://twitter.com/lmoroney)
License: CC BY 4.0

# Overview 
Via Laurence Maroney:

> Rock Paper Scissors contains images from a variety of different hands, from different races, ages and genders, posed into Rock / Paper or Scissors and labelled as such. You can download the training set here, and the test set here. These images have all been generated using CGI techniques as an experiment in determining if a CGI-based dataset can be used for classification against real images. I also generated a few images that you can use for predictions. You can find them here.

Note that all of this data is posed against a white background.

Each image is 300×300 pixels in 24-bit color.

Note: This is an smaller version of the original dataset which can be found [here](https://public.roboflow.com/classification/rock-paper-scissors)