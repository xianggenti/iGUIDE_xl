
Rock Paper Scissors (Small) - v1 300x300-raw
==============================

This dataset was exported via roboflow.ai on June 3, 2021 at 4:23 PM GMT

It includes 900 images.
Hand-Signs are annotated in folder format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


